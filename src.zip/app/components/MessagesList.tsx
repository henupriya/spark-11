import { Send, Video } from 'lucide-react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Message {
  id: number;
  text: string;
  sent: boolean;
  timestamp: string;
}

interface Chat {
  id: number;
  name: string;
  age: number;
  image: string;
  messages: Message[];
}

interface MessagesListProps {
  selectedChat: Chat | null;
  onBack: () => void;
  onVideoCall?: (chat: Chat) => void;
}

export function MessagesList({ selectedChat, onBack, onVideoCall }: MessagesListProps) {
  const [newMessage, setNewMessage] = useState('');

  if (!selectedChat) {
    return (
      <div className="h-full flex items-center justify-center text-gray-400">
        <p>Select a match to start chatting</p>
      </div>
    );
  }

  const handleSend = () => {
    if (newMessage.trim()) {
      setNewMessage('');
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-3 p-4 bg-white border-b">
        <button onClick={onBack} className="text-gray-600 hover:text-gray-900">
          ←
        </button>
        <ImageWithFallback
          src={selectedChat.image}
          alt={selectedChat.name}
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="flex-1">
          <h3 className="font-medium">
            {selectedChat.name}, {selectedChat.age}
          </h3>
          <p className="text-xs text-green-500">Active now</p>
        </div>
        <button
          onClick={() => onVideoCall?.(selectedChat)}
          className="p-2 rounded-full bg-gradient-to-r from-pink-500 to-orange-500 text-white hover:shadow-lg transition-all"
          aria-label="Start video call"
        >
          <Video className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {selectedChat.messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sent ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] rounded-2xl px-4 py-2 ${
                message.sent
                  ? 'bg-pink-500 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <p>{message.text}</p>
              <p
                className={`text-xs mt-1 ${
                  message.sent ? 'text-pink-100' : 'text-gray-500'
                }`}
              >
                {message.timestamp}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 bg-white border-t">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="flex-1 px-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:border-pink-500"
          />
          <button
            onClick={handleSend}
            className="w-10 h-10 rounded-full bg-pink-500 text-white flex items-center justify-center hover:bg-pink-600 transition-colors"
            aria-label="Send message"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
