import { Settings, Edit2, Camera } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface UserProfileProps {
  user: {
    name: string;
    age: number;
    bio: string;
    location: string;
    images: string[];
    interests: string[];
  };
}

export function UserProfile({ user }: UserProfileProps) {
  return (
    <div className="h-full overflow-y-auto bg-gray-50">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2>Profile</h2>
          <button className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <Settings className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="bg-white rounded-2xl p-6 mb-4">
          <div className="relative mb-4">
            <ImageWithFallback
              src={user.images[0]}
              alt={user.name}
              className="w-32 h-32 rounded-full object-cover mx-auto"
            />
            <button className="absolute bottom-0 right-[calc(50%-64px)] bg-pink-500 text-white p-2 rounded-full shadow-lg">
              <Camera className="w-5 h-5" />
            </button>
          </div>

          <div className="text-center mb-4">
            <h3 className="flex items-center justify-center gap-2">
              {user.name}, {user.age}
              <button className="text-pink-500">
                <Edit2 className="w-4 h-4" />
              </button>
            </h3>
            <p className="text-gray-600">{user.location}</p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-700">About</h4>
                <button className="text-pink-500 text-sm">Edit</button>
              </div>
              <p className="text-gray-600">{user.bio}</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-700">Interests</h4>
                <button className="text-pink-500 text-sm">Edit</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {user.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1 bg-pink-50 text-pink-600 rounded-full text-sm"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 mb-4">
          <h3 className="mb-4">Photos</h3>
          <div className="grid grid-cols-3 gap-3">
            {user.images.map((image, index) => (
              <div key={index} className="relative aspect-square">
                <ImageWithFallback
                  src={image}
                  alt={`Photo ${index + 1}`}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
            ))}
            <button className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center hover:border-pink-500 hover:bg-pink-50 transition-colors">
              <Camera className="w-8 h-8 text-gray-400" />
            </button>
          </div>
        </div>

        <button className="w-full py-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors">
          Log out
        </button>
      </div>
    </div>
  );
}
