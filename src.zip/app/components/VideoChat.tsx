import { Video, VideoOff, Mic, MicOff, Phone, Maximize2, Camera, Volume2 } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface VideoChatProps {
  partnerName: string;
  partnerImage: string;
  onEndCall: () => void;
}

export function VideoChat({ partnerName, partnerImage, onEndCall }: VideoChatProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const localVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Simulate connection delay
    const timer = setTimeout(() => setIsConnecting(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Mock: In production, this would initialize WebRTC
    if (localVideoRef.current && !isVideoOff) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch((err) => console.log('Camera access denied:', err));
    }
  }, [isVideoOff]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Partner Video (Main) */}
      <div className="flex-1 relative">
        {isConnecting ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
            <div className="w-24 h-24 rounded-full bg-white/20 mb-4 flex items-center justify-center">
              <ImageWithFallback
                src={partnerImage}
                alt={partnerName}
                className="w-20 h-20 rounded-full object-cover"
              />
            </div>
            <p className="text-xl mb-2">Calling {partnerName}...</p>
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        ) : (
          <div className="absolute inset-0 bg-gradient-to-b from-gray-800 to-gray-900 flex items-center justify-center">
            {/* Mock partner video - in production this would be the remote stream */}
            <ImageWithFallback
              src={partnerImage}
              alt={partnerName}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Partner Name Overlay */}
        {!isConnecting && (
          <div className="absolute top-4 left-4 bg-black/50 text-white px-4 py-2 rounded-full backdrop-blur-sm">
            <p className="text-sm">{partnerName}</p>
          </div>
        )}

        {/* Local Video (Picture-in-Picture) */}
        {!isConnecting && (
          <div className="absolute top-4 right-4 w-24 h-32 bg-gray-800 rounded-lg overflow-hidden shadow-xl border-2 border-white/30">
            {isVideoOff ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-700">
                <VideoOff className="w-8 h-8 text-white/50" />
              </div>
            ) : (
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover mirror"
              />
            )}
          </div>
        )}

        {/* Connection Quality Indicator */}
        {!isConnecting && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/50 text-white px-3 py-1 rounded-full text-xs backdrop-blur-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            HD Quality
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="bg-gradient-to-t from-black/90 to-transparent p-6">
        <div className="flex justify-center items-center gap-4">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
              isMuted ? 'bg-red-500' : 'bg-white/20 hover:bg-white/30'
            }`}
          >
            {isMuted ? (
              <MicOff className="w-6 h-6 text-white" />
            ) : (
              <Mic className="w-6 h-6 text-white" />
            )}
          </button>

          <button
            onClick={onEndCall}
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors shadow-lg"
          >
            <Phone className="w-7 h-7 text-white rotate-135" />
          </button>

          <button
            onClick={() => setIsVideoOff(!isVideoOff)}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
              isVideoOff ? 'bg-red-500' : 'bg-white/20 hover:bg-white/30'
            }`}
          >
            {isVideoOff ? (
              <VideoOff className="w-6 h-6 text-white" />
            ) : (
              <Video className="w-6 h-6 text-white" />
            )}
          </button>
        </div>

        <div className="flex justify-center gap-6 mt-4">
          <button className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors">
            <Camera className="w-5 h-5" />
            <span className="text-xs">Flip</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors">
            <Volume2 className="w-5 h-5" />
            <span className="text-xs">Speaker</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors">
            <Maximize2 className="w-5 h-5" />
            <span className="text-xs">Fullscreen</span>
          </button>
        </div>
      </div>

      <style>{`
        .mirror {
          transform: scaleX(-1);
        }
      `}</style>
    </div>
  );
}
