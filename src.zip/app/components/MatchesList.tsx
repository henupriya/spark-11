import { MessageCircle, Video } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Match {
  id: number;
  name: string;
  age: number;
  image: string;
  lastMessage?: string;
  timestamp?: string;
}

interface MatchesListProps {
  matches: Match[];
  onSelectMatch: (match: Match) => void;
  onVideoCall?: (match: Match) => void;
}

export function MatchesList({ matches, onSelectMatch, onVideoCall }: MatchesListProps) {
  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6">
        <h2 className="mb-6">Your Matches</h2>
        <div className="space-y-3">
          {matches.map((match) => (
            <div
              key={match.id}
              className="w-full flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm"
            >
              <button
                onClick={() => onSelectMatch(match)}
                className="flex items-center gap-4 flex-1 hover:opacity-80 transition-opacity"
              >
                <div className="relative">
                  <ImageWithFallback
                    src={match.image}
                    alt={match.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-medium">
                    {match.name}, {match.age}
                  </h3>
                  {match.lastMessage && (
                    <p className="text-sm text-gray-500 truncate">{match.lastMessage}</p>
                  )}
                </div>
                {match.timestamp && (
                  <span className="text-xs text-gray-400">{match.timestamp}</span>
                )}
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => onVideoCall?.(match)}
                  className="p-3 rounded-full bg-gradient-to-r from-pink-500 to-orange-500 text-white hover:shadow-lg transition-all"
                  aria-label="Start video call"
                >
                  <Video className="w-5 h-5" />
                </button>
                <button
                  onClick={() => onSelectMatch(match)}
                  className="p-3 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
                  aria-label="Send message"
                >
                  <MessageCircle className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
