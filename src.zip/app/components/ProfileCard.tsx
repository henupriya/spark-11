import { Heart, X, Info, MapPin } from 'lucide-react';
import { motion, useMotionValue, useTransform } from 'motion/react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Profile {
  id: number;
  name: string;
  age: number;
  bio: string;
  location: string;
  images: string[];
  interests: string[];
}

interface ProfileCardProps {
  profile: Profile;
  onSwipe: (direction: 'left' | 'right') => void;
  isTop: boolean;
}

export function ProfileCard({ profile, onSwipe, isTop }: ProfileCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showInfo, setShowInfo] = useState(false);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_event: any, info: any) => {
    if (Math.abs(info.offset.x) > 100) {
      onSwipe(info.offset.x > 0 ? 'right' : 'left');
    }
  };

  const handleAction = (action: 'left' | 'right') => {
    onSwipe(action);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) =>
      prev < profile.images.length - 1 ? prev + 1 : prev
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev > 0 ? prev - 1 : prev));
  };

  return (
    <motion.div
      style={{ x, rotate, opacity }}
      drag={isTop ? 'x' : false}
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      className={`absolute inset-0 ${!isTop ? 'pointer-events-none' : ''}`}
    >
      <div className="relative h-full bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="relative h-[70%]">
          <ImageWithFallback
            src={profile.images[currentImageIndex]}
            alt={profile.name}
            className="w-full h-full object-cover"
          />

          <div className="absolute top-0 left-0 right-0 flex gap-1 p-2">
            {profile.images.map((_, index) => (
              <div
                key={index}
                className="flex-1 h-1 rounded-full bg-white/30"
              >
                <div
                  className={`h-full rounded-full transition-all ${
                    index <= currentImageIndex ? 'bg-white' : 'bg-transparent'
                  }`}
                />
              </div>
            ))}
          </div>

          <div className="absolute inset-0 flex">
            <button
              onClick={prevImage}
              className="flex-1 cursor-pointer"
              aria-label="Previous image"
            />
            <button
              onClick={nextImage}
              className="flex-1 cursor-pointer"
              aria-label="Next image"
            />
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/60 to-transparent text-white">
            <h2 className="flex items-center gap-2">
              {profile.name}, {profile.age}
            </h2>
            <p className="flex items-center gap-1 text-sm opacity-90 mt-1">
              <MapPin className="w-4 h-4" />
              {profile.location}
            </p>
          </div>
        </div>

        <div className="h-[30%] p-6 overflow-y-auto">
          {showInfo ? (
            <div>
              <p className="text-gray-700 mb-4">{profile.bio}</p>
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1 bg-pink-50 text-pink-600 rounded-full text-sm"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-gray-700">{profile.bio}</p>
          )}
        </div>

        {isTop && (
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4 px-6">
            <button
              onClick={() => handleAction('left')}
              className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
              aria-label="Pass"
            >
              <X className="w-7 h-7 text-red-500" />
            </button>
            <button
              onClick={() => setShowInfo(!showInfo)}
              className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
              aria-label="Show info"
            >
              <Info className="w-5 h-5 text-blue-500" />
            </button>
            <button
              onClick={() => handleAction('right')}
              className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
              aria-label="Like"
            >
              <Heart className="w-7 h-7 text-pink-500" />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
