import { useState } from 'react';
import { Heart, MessageCircle, User, Flame } from 'lucide-react';
import { ProfileCard } from './components/ProfileCard';
import { MatchesList } from './components/MatchesList';
import { MessagesList } from './components/MessagesList';
import { UserProfile } from './components/UserProfile';
import { VideoChat } from './components/VideoChat';
import { PaymentModal } from './components/PaymentModal';

const mockProfiles = [
  {
    id: 1,
    name: 'Emma',
    age: 28,
    bio: 'Coffee enthusiast ☕ | Love hiking and exploring new trails | Looking for adventure partner',
    location: '2 miles away',
    images: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800',
    ],
    interests: ['Hiking', 'Photography', 'Coffee', 'Travel', 'Yoga'],
  },
  {
    id: 2,
    name: 'Olivia',
    age: 26,
    bio: 'Artist 🎨 | Dog mom | Foodie | Always up for trying new restaurants',
    location: '5 miles away',
    images: [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800',
      'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=800',
      'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800',
    ],
    interests: ['Art', 'Dogs', 'Cooking', 'Live Music', 'Wine'],
  },
  {
    id: 3,
    name: 'Sophia',
    age: 29,
    bio: 'Fitness instructor | Marathon runner 🏃‍♀️ | Plant-based living | Beach lover',
    location: '3 miles away',
    images: [
      'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=800',
      'https://images.unsplash.com/photo-1524638431109-93d95c968f03?w=800',
      'https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?w=800',
    ],
    interests: ['Fitness', 'Running', 'Health', 'Beach', 'Meditation'],
  },
];

const mockMatches = [
  {
    id: 1,
    name: 'Jessica',
    age: 27,
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400',
    lastMessage: 'Hey! How was your weekend?',
    timestamp: '2h ago',
  },
  {
    id: 2,
    name: 'Ashley',
    age: 25,
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
    lastMessage: 'That sounds amazing! 😊',
    timestamp: '5h ago',
  },
  {
    id: 3,
    name: 'Madison',
    age: 30,
    image: 'https://images.unsplash.com/photo-1500917293891-ef795e70e1f6?w=400',
    lastMessage: "I'd love to grab coffee sometime!",
    timestamp: '1d ago',
  },
];

const mockChat = {
  id: 1,
  name: 'Jessica',
  age: 27,
  image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400',
  messages: [
    { id: 1, text: 'Hey! How are you?', sent: false, timestamp: '10:30 AM' },
    { id: 2, text: "Hi! I'm great, thanks! How about you?", sent: true, timestamp: '10:32 AM' },
    { id: 3, text: 'Doing well! I saw you like hiking', sent: false, timestamp: '10:33 AM' },
    { id: 4, text: 'Yes! Love it! Do you hike too?', sent: true, timestamp: '10:35 AM' },
    { id: 5, text: 'Absolutely! Maybe we could go together sometime?', sent: false, timestamp: '10:36 AM' },
  ],
};

const currentUser = {
  name: 'Alex',
  age: 27,
  bio: 'Software engineer | Outdoor enthusiast | Coffee addict ☕ | Looking for meaningful connections',
  location: 'San Francisco, CA',
  images: [
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800',
    'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=800',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800',
  ],
  interests: ['Tech', 'Hiking', 'Coffee', 'Photography', 'Travel', 'Music'],
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'discover' | 'matches' | 'messages' | 'profile'>('discover');
  const [profiles, setProfiles] = useState(mockProfiles);
  const [selectedChat, setSelectedChat] = useState<typeof mockChat | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showVideoChat, setShowVideoChat] = useState(false);
  const [videoCallPartner, setVideoCallPartner] = useState<{ name: string; image: string } | null>(null);

  const handleSwipe = (direction: 'left' | 'right') => {
    if (direction === 'right') {
      console.log('Liked!');
    }
    setProfiles((prev) => prev.slice(1));
  };

  const handleSelectMatch = (match: any) => {
    setSelectedChat(mockChat);
    setActiveTab('messages');
  };

  const handleVideoCall = (partner: { name: string; image: string }) => {
    setVideoCallPartner(partner);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = () => {
    setShowPaymentModal(false);
    setShowVideoChat(true);
  };

  const handleEndCall = () => {
    setShowVideoChat(false);
    setVideoCallPartner(null);
  };

  return (
    <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
      <header className="bg-gradient-to-r from-pink-500 to-orange-500 text-white p-4 flex items-center justify-center shadow-lg">
        <Flame className="w-8 h-8 mr-2" />
        <h1 className="text-2xl">Spark</h1>
      </header>

      <main className="flex-1 overflow-hidden">
        {activeTab === 'discover' && (
          <div className="relative h-full p-4">
            {profiles.length === 0 ? (
              <div className="h-full flex items-center justify-center text-gray-400">
                <p>No more profiles to show</p>
              </div>
            ) : (
              <div className="relative h-full">
                {profiles.slice(0, 3).map((profile, index) => (
                  <ProfileCard
                    key={profile.id}
                    profile={profile}
                    onSwipe={handleSwipe}
                    isTop={index === 0}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'matches' && (
          <MatchesList
            matches={mockMatches}
            onSelectMatch={handleSelectMatch}
            onVideoCall={handleVideoCall}
          />
        )}

        {activeTab === 'messages' && (
          <MessagesList
            selectedChat={selectedChat}
            onBack={() => setSelectedChat(null)}
            onVideoCall={handleVideoCall}
          />
        )}

        {activeTab === 'profile' && <UserProfile user={currentUser} />}
      </main>

      {/* Payment Modal */}
      {showPaymentModal && videoCallPartner && (
        <PaymentModal
          onClose={() => {
            setShowPaymentModal(false);
            setVideoCallPartner(null);
          }}
          onPaymentSuccess={handlePaymentSuccess}
          partnerName={videoCallPartner.name}
        />
      )}

      {/* Video Chat */}
      {showVideoChat && videoCallPartner && (
        <VideoChat
          partnerName={videoCallPartner.name}
          partnerImage={videoCallPartner.image}
          onEndCall={handleEndCall}
        />
      )}

      <nav className="bg-white border-t border-gray-200 px-6 py-3 flex justify-around items-center">
        <button
          onClick={() => setActiveTab('discover')}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'discover' ? 'text-pink-500' : 'text-gray-400'
          }`}
        >
          <Flame className="w-6 h-6" />
          <span className="text-xs">Discover</span>
        </button>
        <button
          onClick={() => setActiveTab('matches')}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'matches' ? 'text-pink-500' : 'text-gray-400'
          }`}
        >
          <Heart className="w-6 h-6" />
          <span className="text-xs">Matches</span>
        </button>
        <button
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'messages' ? 'text-pink-500' : 'text-gray-400'
          }`}
        >
          <MessageCircle className="w-6 h-6" />
          <span className="text-xs">Messages</span>
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeTab === 'profile' ? 'text-pink-500' : 'text-gray-400'
          }`}
        >
          <User className="w-6 h-6" />
          <span className="text-xs">Profile</span>
        </button>
      </nav>
    </div>
  );
}